# regras do proguard (vazio de propósito)
