package com.meuapp.iaoffline

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            IaTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot(vm: ChatViewModel = viewModel()) {
    val tela by vm.tela.collectAsState()
    val cfg by vm.cfg.collectAsState()
    val estadoIa by vm.estadoModelo.collectAsState()
    var abrindo by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        delay(Marca.SPLASH_MS)
        abrindo = false
    }
    val copiando = estadoIa as? EstadoModelo.Copiando

    BackHandler(
        enabled = tela == Tela.HISTORICO || tela == Tela.AJUSTES || tela == Tela.ATELIE ||
            tela == Tela.MEMORIA || (tela == Tela.MODELO && cfg.setupFeito)
    ) {
        vm.tela.value = Tela.CHAT
    }

    Box(Modifier.fillMaxSize()) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when (tela) {
                Tela.SETUP -> TelaSetup(vm)
                Tela.MODELO -> TelaModelo(vm)
                Tela.CHAT -> TelaChat(vm)
                Tela.HISTORICO -> TelaHistorico(vm)
                Tela.AJUSTES -> TelaAjustes(vm)
                Tela.ATELIE -> TelaAtelie(vm)
                Tela.MEMORIA -> TelaMemoria(vm)
            }
        }
        if (abrindo || copiando != null) {
            TelaAbertura(
                if (copiando != null) "Preparando a IA pela primeira vez… ${copiando.pct}%  (só acontece uma vez)"
                else "iniciando…"
            )
        }
    }
}
