package com.meuapp.iaoffline

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.view.View
import android.webkit.WebView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File
import java.io.FileOutputStream

class Traco(val cor: Color, val largura: Float, val pontos: List<Offset>)

private fun exportarPng(ctx: Context, tracos: List<Traco>, w: Int, h: Int, fundo: Int): File? {
    if (w <= 0 || h <= 0) return null
    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val cv = android.graphics.Canvas(bmp)
    cv.drawColor(fundo)
    for (t in tracos) {
        val tinta = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        tinta.color = t.cor.toArgb()
        tinta.strokeWidth = t.largura
        tinta.strokeCap = android.graphics.Paint.Cap.ROUND
        tinta.strokeJoin = android.graphics.Paint.Join.ROUND
        if (t.pontos.size == 1) {
            tinta.style = android.graphics.Paint.Style.FILL
            cv.drawCircle(t.pontos[0].x, t.pontos[0].y, t.largura / 2f, tinta)
        } else {
            tinta.style = android.graphics.Paint.Style.STROKE
            val caminho = android.graphics.Path()
            caminho.moveTo(t.pontos[0].x, t.pontos[0].y)
            for (k in 1 until t.pontos.size) caminho.lineTo(t.pontos[k].x, t.pontos[k].y)
            cv.drawPath(caminho, tinta)
        }
    }
    return salvarBitmap(ctx, bmp, "jhamk-pintura")
}

private fun salvarBitmap(ctx: Context, bmp: Bitmap, prefixo: String): File {
    val f = File(Arquivos.pastaDeExportacao(ctx), prefixo + "-" + System.currentTimeMillis() + ".png")
    FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    return f
}

private fun entregarPng(ctx: Context, f: File, vm: ChatViewModel) {
    if (Arquivos.salvarNaGaleria(ctx, f)) vm.aviso.value = "🖼 Imagem salva na galeria (pasta jHamk)."
    Arquivos.compartilhar(ctx, f, "image/png")
}

@Composable
fun TelaAtelie(vm: ChatViewModel) {
    var aba by remember { mutableStateOf(0) }
    val aviso by vm.aviso.collectAsState()

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.tela.value = Tela.CHAT }) { Text("← Voltar") }
            Text("🎨 Ateliê do ${Marca.NOME}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = aba == 0, onClick = { aba = 0 }, label = { Text("✨ ${Marca.NOME} cria") })
            FilterChip(selected = aba == 1, onClick = { aba = 1 }, label = { Text("🖌 Pintar") })
        }
        if (aviso != null) {
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(aviso ?: "", modifier = Modifier.weight(1f), fontSize = 13.sp, color = Cores.Destaque)
                TextButton(onClick = { vm.aviso.value = null }) { Text("OK") }
            }
        }
        Spacer(Modifier.height(6.dp))
        if (aba == 0) PainelArte(vm, Modifier.weight(1f)) else PainelPintura(vm, Modifier.weight(1f))
    }
}

// ------------------------------------------------------------ o jHamk.ia desenha (SVG)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun PainelArte(vm: ChatViewModel, modifier: Modifier) {
    val ctx = LocalContext.current
    val svg by vm.arte.collectAsState()
    val criando by vm.criandoArte.collectAsState()
    var pedido by remember { mutableStateOf("") }
    var web by remember { mutableStateOf<WebView?>(null) }

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            val atual = svg
            if (atual == null) {
                Text(
                    "Descreva a arte lá embaixo e toque em Criar.\nO ${Marca.NOME} desenha com código (SVG), sem limite de imagens.",
                    modifier = Modifier.padding(20.dp),
                    color = Cores.Cinza
                )
            } else {
                val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                    "<style>html,body{margin:0;height:100%;background:#000;display:flex;align-items:center;justify-content:center}" +
                    "svg{width:100%;height:100%}</style></head><body>" + atual + "</body></html>"
                AndroidView(
                    factory = { c ->
                        WebView(c).apply {
                            setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                            settings.javaScriptEnabled = false
                            setBackgroundColor(android.graphics.Color.BLACK)
                            web = this
                        }
                    },
                    update = { w ->
                        if (w.tag != html) {
                            w.tag = html
                            w.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (criando) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(8.dp))
                    Text("Pintando…", color = Cores.Destaque)
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(
                "cidade futurista neon à noite",
                "pôr do sol numa praia",
                "galáxia com planetas",
                "floresta mágica brilhando",
                "dragão verde neon",
                "mandala colorida"
            ).forEach { s ->
                AssistChip(onClick = { pedido = s }, label = { Text(s) })
            }
        }

        OutlinedTextField(
            value = pedido,
            onValueChange = { pedido = it },
            label = { Text("O que o ${Marca.NOME} deve pintar?") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (criando) {
                Button(onClick = { vm.pararArte() }) { Text("⏹ Parar") }
            } else {
                Button(onClick = { vm.criarArte(pedido, false) }, enabled = pedido.isNotBlank()) { Text("🎨 Criar") }
                OutlinedButton(
                    onClick = { vm.criarArte(pedido, true) },
                    enabled = pedido.isNotBlank() && svg != null
                ) { Text("✏️ Refinar") }
            }
        }
        if (svg != null && !criando) {
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(onClick = {
                    try {
                        val f = Arquivos.salvarTexto(ctx, "jhamk-arte-" + System.currentTimeMillis() + ".svg", svg ?: "")
                        Arquivos.salvarEmDownloads(ctx, f, "image/svg+xml")
                        Arquivos.compartilhar(ctx, f, "image/svg+xml")
                    } catch (e: Exception) {
                        vm.aviso.value = "Não consegui salvar: ${e.message}"
                    }
                }) { Text("💾 SVG") }
                OutlinedButton(onClick = {
                    val w = web
                    if (w == null || w.width <= 0 || w.height <= 0) {
                        vm.aviso.value = "Espere a arte aparecer na tela e tente de novo."
                    } else {
                        try {
                            val bmp = Bitmap.createBitmap(w.width, w.height, Bitmap.Config.ARGB_8888)
                            w.draw(android.graphics.Canvas(bmp))
                            entregarPng(ctx, salvarBitmap(ctx, bmp, "jhamk-arte"), vm)
                        } catch (e: Exception) {
                            vm.aviso.value = "Não consegui salvar a imagem: ${e.message}"
                        }
                    }
                }) { Text("🖼 PNG") }
            }
        }
    }
}

// ------------------------------------------------------------ você pinta

@Composable
fun PainelPintura(vm: ChatViewModel, modifier: Modifier) {
    val ctx = LocalContext.current
    val tracos = remember { mutableStateListOf<Traco>() }
    var atual by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var cor by remember { mutableStateOf(Color(0xFF22FF2A)) }
    var largura by remember { mutableStateOf(10f) }
    var fundoEscuro by remember { mutableStateOf(true) }
    var tamanho by remember { mutableStateOf(IntSize.Zero) }

    val corAtual by rememberUpdatedState(cor)
    val larguraAtual by rememberUpdatedState(largura)
    val fundo = if (fundoEscuro) Color.Black else Color.White

    val paleta = listOf(
        Color(0xFF22FF2A), Color(0xFFFFFFFF), Color(0xFFFF3B30), Color(0xFFFF9500),
        Color(0xFFFFE600), Color(0xFF00C7FF), Color(0xFF3D5AFE), Color(0xFFD500F9),
        Color(0xFFFF4081), Color(0xFF8D6E63), Color(0xFF000000)
    )

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Canvas(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp))
                .background(fundo)
                .onSizeChanged { tamanho = it }
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { p -> atual = listOf(p) },
                        onDrag = { change, _ ->
                            change.consume()
                            atual = atual + change.position
                        },
                        onDragEnd = {
                            if (atual.isNotEmpty()) tracos.add(Traco(corAtual, larguraAtual, atual))
                            atual = emptyList()
                        },
                        onDragCancel = { atual = emptyList() }
                    )
                }
        ) {
            fun desenhar(pontos: List<Offset>, c: Color, w: Float) {
                if (pontos.isEmpty()) return
                if (pontos.size == 1) {
                    drawCircle(c, w / 2f, pontos[0])
                } else {
                    val caminho = Path()
                    caminho.moveTo(pontos[0].x, pontos[0].y)
                    for (k in 1 until pontos.size) caminho.lineTo(pontos[k].x, pontos[k].y)
                    drawPath(caminho, c, style = Stroke(width = w, cap = StrokeCap.Round, join = StrokeJoin.Round))
                }
            }
            for (t in tracos) desenhar(t.pontos, t.cor, t.largura)
            desenhar(atual, cor, largura)
        }

        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            paleta.forEach { c ->
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(c)
                        .border(
                            if (c == cor) 3.dp else 1.dp,
                            if (c == cor) Cores.Destaque else Color(0xFF555555),
                            CircleShape
                        )
                        .clickable { cor = c }
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Pincel", fontSize = 13.sp)
            Slider(
                value = largura,
                onValueChange = { largura = it },
                valueRange = 2f..60f,
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
            )
            Text("${largura.toInt()}", fontSize = 13.sp)
        }
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = { if (tracos.isNotEmpty()) tracos.removeAt(tracos.lastIndex) }) { Text("↩ Desfazer") }
            OutlinedButton(onClick = { tracos.clear() }) { Text("🗑 Limpar") }
            OutlinedButton(onClick = { fundoEscuro = !fundoEscuro }) { Text(if (fundoEscuro) "☀ Fundo claro" else "🌙 Fundo escuro") }
            Button(onClick = {
                val f = exportarPng(ctx, tracos.toList(), tamanho.width, tamanho.height, fundo.toArgb())
                if (f == null) vm.aviso.value = "Nada para salvar ainda."
                else entregarPng(ctx, f, vm)
            }) { Text("💾 Salvar PNG") }
        }
    }
}
