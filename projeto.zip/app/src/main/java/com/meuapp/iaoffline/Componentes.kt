package com.meuapp.iaoffline

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Botão quadrado arredondado com ícone, com borda na cor do tema. */
@Composable
fun BotaoIcone(icone: ImageVector, aoClicar: () -> Unit, tamanho: Dp = 44.dp) {
    val forma = RoundedCornerShape(14.dp)
    Box(
        Modifier
            .size(tamanho)
            .clip(forma)
            .background(Cores.Superficie)
            .border(1.dp, Cores.Destaque.copy(alpha = 0.40f), forma)
            .clickable(onClick = aoClicar),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icone,
            contentDescription = null,
            tint = Cores.Destaque,
            modifier = Modifier.size(tamanho * 0.5f)
        )
    }
}

/** Botão em formato de pílula (modos, atalhos), com ícone opcional. */
@Composable
fun ChipModo(
    texto: String,
    selecionado: Boolean,
    icone: ImageVector? = null,
    modifier: Modifier = Modifier,
    aoClicar: () -> Unit
) {
    val forma = RoundedCornerShape(50)
    val cor = if (selecionado) Cores.Destaque else Color(0xFFECF5EE)
    Row(
        modifier
            .clip(forma)
            .background(if (selecionado) Cores.Destaque.copy(alpha = 0.20f) else Cores.Superficie)
            .border(
                1.dp,
                if (selecionado) Cores.Destaque else Cores.Destaque.copy(alpha = 0.25f),
                forma
            )
            .clickable(onClick = aoClicar)
            .padding(horizontal = 8.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        if (icone != null) {
            Icon(
                imageVector = icone,
                contentDescription = null,
                tint = cor,
                modifier = Modifier.size(17.dp)
            )
            Spacer(Modifier.width(6.dp))
        }
        Text(
            texto,
            fontSize = 13.sp,
            fontWeight = if (selecionado) FontWeight.Bold else FontWeight.Medium,
            color = cor,
            maxLines = 1,
            softWrap = false
        )
    }
}

/** Botão redondo de enviar, com degradê do tema. */
@Composable
fun BotaoEnviar(icone: ImageVector, aoClicar: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Cores.Destaque, Cores.Secundaria)))
            .clickable(onClick = aoClicar),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icone,
            contentDescription = null,
            tint = Color(0xFF021004),
            modifier = Modifier.size(24.dp)
        )
    }
}

/** Pílula de status no topo do chat (pronto / pensando…). */
@Composable
fun StatusPill(texto: String, ocupado: Boolean, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "status")
    val brilho by t.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "brilho"
    )
    val forma = RoundedCornerShape(50)
    Row(
        modifier
            .clip(forma)
            .background(Cores.Superficie)
            .border(1.dp, Cores.Destaque.copy(alpha = 0.25f), forma)
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(Cores.Destaque.copy(alpha = if (ocupado) brilho else 1f))
        )
        Spacer(Modifier.width(8.dp))
        Text(texto, fontSize = 12.sp, color = Cores.Cinza, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Informação fixa (o usuário só lê): título pequeno e valor em destaque, sem caixa e sem cadeado. */
@Composable
fun LinhaFixa(titulo: String, valor: String) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(titulo, fontSize = 12.sp, color = Cores.Cinza)
        Text(valor, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Cores.Destaque)
    }
}

/** Bolinhas de cor para o usuário escolher o tema do app (cabem todas na tela). */
@Composable
fun SeletorTema(aoEscolher: (Int) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Cores.Temas.forEachIndexed { i, t ->
            val sel = i == Cores.temaIndice
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .weight(1f)
                    .clickable { aoEscolher(i) }
            ) {
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(t.principal, t.secundaria)))
                        .border(if (sel) 3.dp else 1.dp, if (sel) Color.White else Color(0x44FFFFFF), CircleShape)
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    t.nome,
                    fontSize = 10.sp,
                    color = if (sel) Color.White else Cores.Cinza,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

/** Logo do app respirando, com borda brilhante. */
@Composable
fun LogoHeroi(tamanho: Dp = 112.dp) {
    val t = rememberInfiniteTransition(label = "heroi")
    val respira by t.animateFloat(
        initialValue = 1f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "respira"
    )
    val brilho by t.animateFloat(
        initialValue = 0.2f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "brilho"
    )
    val forma = RoundedCornerShape(tamanho * 0.23f)
    Image(
        painter = painterResource(R.drawable.kalberdex_capa),
        contentDescription = null,
        modifier = Modifier
            .size(tamanho)
            .graphicsLayer {
                scaleX = respira
                scaleY = respira
            }
            .clip(forma)
            .border(2.dp, Cores.Destaque.copy(alpha = brilho), forma)
    )
}
