package com.meuapp.iaoffline

import java.util.UUID

const val PROMPT_PADRAO = """Você se chama {nome}. Você é o assistente pessoal de {usuario}, o chefe e dono deste aplicativo.
Você roda dentro do celular dele, funciona sem internet e aprende com o que ele ensina e com o que pesquisa.
Seja direto, inteligente e prestativo. Responda sempre em português do Brasil, de forma clara e curta, a menos que {usuario} peça mais detalhes.
Quando houver "Memória" ou "Pesquisa na internet" no contexto, use essas informações como base e diga quando algo veio delas.
Se você não souber algo, diga que não sabe em vez de inventar."""

const val PROMPT_PROGRAMADOR = """Você se chama {nome} e está no MODO PROGRAMADOR, trabalhando como engenheiro de software sênior para {usuario}.
Regras:
1. Entenda o pedido, escolha uma estrutura simples e profissional e escreva código completo, que funciona, sem trechos faltando e sem reticências no lugar do código.
2. Para cada arquivo, escreva uma linha exatamente assim: ### arquivo: pasta/nome.ext
   e logo abaixo um bloco de código (três crases) com o conteúdo COMPLETO do arquivo.
3. Para sites, sempre crie index.html, e coloque o CSS em style.css e o JavaScript em script.js. Os sites devem ser responsivos, modernos e bonitos.
4. Depois dos arquivos, explique em poucas linhas como usar.
5. Se o pedido for grande, entregue por partes e diga o que falta. Os arquivos de todas as respostas entram no ZIP do projeto.
6. Responda em português do Brasil e escreva os comentários do código em português."""

const val PROMPT_ARTE = """Você é {nome}, um artista digital.
Responda SOMENTE com um único código SVG completo, começando em <svg e terminando em </svg>. Sem explicações e sem crases.
Use viewBox="0 0 512 512". Desenhe o fundo com um retângulo grande, use degradês (linearGradient e radialGradient), muitas formas sobrepostas, filtros de brilho (feGaussianBlur) e cores vibrantes.
Faça composições ricas, bonitas e originais, com detalhes."""

/** role = "user" ou "assistant". foto = caminho de uma miniatura salva no app (opcional). */
data class Msg(val role: String, val text: String, val foto: String? = null)

data class Conversa(
    val id: String,
    val titulo: String,
    val msgs: List<Msg>,
    val atualizadoEm: Long
)

data class Config(
    val nomeIa: String = "Hamk",
    val nomeUsuario: String = "Chefe",
    val promptSistema: String = PROMPT_PADRAO,
    val internet: Boolean = true,
    val microfone: Boolean = true,
    val camera: Boolean = true,
    val falarRespostas: Boolean = false,
    val maxTokens: Int = 4096,
    val temperatura: Float = 0.8f,
    val setupFeito: Boolean = false,
    val caminhoModelo: String = "",
    val nomeModelo: String = ""
)

enum class Tela { SETUP, MODELO, CHAT, HISTORICO, AJUSTES, ATELIE, MEMORIA }

enum class Modo { CONVERSA, PROGRAMADOR }

sealed interface EstadoModelo {
    data object Nenhum : EstadoModelo
    data class Copiando(val pct: Int) : EstadoModelo
    data object Carregando : EstadoModelo
    data object Pronto : EstadoModelo
    data class Erro(val msg: String) : EstadoModelo
}

fun novoId(): String = UUID.randomUUID().toString()
