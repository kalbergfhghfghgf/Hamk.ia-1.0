package com.meuapp.iaoffline

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession

/**
 * Motor da IA local (MediaPipe LLM Inference).
 * Todo o código que fala com a biblioteca da IA fica neste arquivo.
 * Os recursos de imagem usam "reflexão": se a biblioteca mudar, o app não quebra, só avisa que não enxerga.
 */
class LlmEngine(private val ctx: Context) {

    private var llm: LlmInference? = null

    @Volatile private var sessao: LlmInferenceSession? = null
    @Volatile var ocupado: Boolean = false
        private set
    @Volatile private var cancelado: Boolean = false
    @Volatile var temVisao: Boolean = false
        private set
    @Volatile private var geracao: Int = 0

    val pronto: Boolean get() = llm != null

    private fun chamar(alvo: Any, nome: String, vararg args: Any?): Any? {
        val m = alvo.javaClass.methods.firstOrNull { it.name == nome && it.parameterTypes.size == args.size }
            ?: throw NoSuchMethodException(nome)
        try { m.isAccessible = true } catch (_: Throwable) {}
        return m.invoke(alvo, *args)
    }

    private fun criar(caminho: String, maxTokens: Int, visao: Boolean): LlmInference {
        val b = LlmInference.LlmInferenceOptions.builder()
            .setModelPath(caminho)
            .setMaxTokens(maxTokens)
        if (visao) chamar(b, "setMaxNumImages", 1)
        return LlmInference.createFromOptions(ctx, b.build())
    }

    fun carregar(caminho: String, maxTokens: Int, tentarVisao: Boolean) {
        descarregar()
        if (tentarVisao) {
            try {
                llm = criar(caminho, maxTokens, true)
                temVisao = true
                return
            } catch (t: Throwable) {
                llm = null
                temVisao = false
            }
        }
        llm = criar(caminho, maxTokens, false)
    }

    fun descarregar() {
        try { sessao?.close() } catch (_: Throwable) {}
        try { llm?.close() } catch (_: Throwable) {}
        sessao = null
        llm = null
        ocupado = false
        temVisao = false
    }

    private fun ativarVisao(opcoesSessao: Any) {
        val classe = Class.forName("com.google.mediapipe.tasks.genai.llminference.GraphOptions")
        val construtor = classe.getMethod("builder").invoke(null)!!
        chamar(construtor, "setEnableVisionModality", true)
        val graficos = chamar(construtor, "build")
        chamar(opcoesSessao, "setGraphOptions", graficos)
    }

    private fun adicionarImagem(s: LlmInferenceSession, bmp: Bitmap) {
        val classe = Class.forName("com.google.mediapipe.framework.image.BitmapImageBuilder")
        val construtor = classe.getConstructor(Bitmap::class.java).newInstance(bmp)
        val imagem = chamar(construtor, "build")
        val m = s.javaClass.methods.first { it.name == "addImage" && it.parameterTypes.size == 1 }
        m.invoke(s, imagem)
    }

    /**
     * Monta a conversa em duas partes: [antes] vem antes da imagem e [depois] vem depois.
     * Sem imagem, as duas partes são enviadas juntas.
     */
    fun gerar(
        antes: String,
        imagem: Bitmap?,
        depois: String,
        temperatura: Float,
        onParcial: (String) -> Unit,
        onFim: (String) -> Unit,
        onErro: (String) -> Unit
    ) {
        val modelo = llm
        if (modelo == null) {
            onErro("A IA local não está carregada.")
            return
        }
        if (imagem != null && !temVisao) {
            onErro("Este modelo não enxerga imagens. Use o Gemma 3n (arquivo .task) para o ${Marca.NOME} ver fotos.")
            return
        }
        if (ocupado) {
            // Ainda tem uma resposta antiga rodando: manda parar e espera um pouco.
            cancelar()
            if (!esperarLivre(4000)) {
                // Travou: solta a sessão antiga à força para não ficar preso.
                try { sessao?.close() } catch (_: Throwable) {}
                sessao = null
                ocupado = false
            }
        }
        val meuId = ++geracao
        ocupado = true
        cancelado = false
        try {
            try { sessao?.close() } catch (_: Throwable) {}
            val opcoes = LlmInferenceSession.LlmInferenceSessionOptions.builder()
                .setTopK(40)
                .setTemperature(temperatura)
                .setRandomSeed((System.currentTimeMillis() % 100000L).toInt())
            if (imagem != null) ativarVisao(opcoes)
            val s = LlmInferenceSession.createFromOptions(modelo, opcoes.build())
            sessao = s
            s.addQueryChunk(antes)
            if (imagem != null) adicionarImagem(s, imagem)
            s.addQueryChunk(depois)
            val acumulado = StringBuilder()
            s.generateResponseAsync { parcial, fim ->
                // Respostas de uma geração antiga (já cancelada) são ignoradas.
                if (meuId != geracao) return@generateResponseAsync
                if (!cancelado) {
                    acumulado.append(parcial)
                    onParcial(acumulado.toString())
                }
                if (fim) {
                    ocupado = false
                    if (!cancelado) onFim(acumulado.toString())
                }
            }
        } catch (t: Throwable) {
            ocupado = false
            onErro(t.message ?: "Erro ao gerar a resposta.")
        }
    }

    private fun esperarLivre(ms: Long): Boolean {
        val limite = System.currentTimeMillis() + ms
        while (ocupado && System.currentTimeMillis() < limite) {
            try { Thread.sleep(50) } catch (_: InterruptedException) { break }
        }
        return !ocupado
    }

    /** Pede para a IA parar de escrever. */
    fun cancelar() {
        cancelado = true
        val s = sessao ?: return
        try {
            s.javaClass.getMethod("cancelGenerateResponseAsync").invoke(s)
        } catch (_: Throwable) {
        }
    }
}
