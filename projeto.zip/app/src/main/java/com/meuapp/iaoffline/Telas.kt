package com.meuapp.iaoffline

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.annotation.SuppressLint
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ============================================================ PRIMEIRA ABERTURA

@Composable
fun TelaSetup(vm: ChatViewModel) {
    val atual by vm.cfg.collectAsState()
    var nomeUsuario by remember { mutableStateOf(if (atual.setupFeito) atual.nomeUsuario else "") }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(12.dp))
        Image(
            painter = painterResource(R.drawable.kalberdex_capa),
            contentDescription = Marca.NOME,
            modifier = Modifier.size(150.dp).clip(RoundedCornerShape(28.dp))
        )
        Text("Bem-vindo, chefe 👋", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(Marca.CREDITO, fontSize = 13.sp, color = Cores.Cinza)
        Text(
            "O ${Marca.NOME} roda no seu celular, funciona sem internet, aprende com você, " +
                "fala, vê fotos, programa e pinta. Você manda, ele obedece.",
            fontSize = 16.sp
        )
        OutlinedTextField(
            value = nomeUsuario,
            onValueChange = { nomeUsuario = it },
            label = { Text("Como ele deve te chamar?") },
            placeholder = { Text("Ex.: Chefe") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { vm.concluirSetup(Marca.NOME, nomeUsuario) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Continuar") }
        Text(
            "Você pode mudar tudo isso depois em ⚙️ Configurações.",
            fontSize = 13.sp,
            color = Cores.Cinza
        )
    }
}

// ============================================================ ESCOLHER MODELO

@Composable
fun TelaModelo(vm: ChatViewModel) {
    val estado by vm.estadoModelo.collectAsState()
    val cfg by vm.cfg.collectAsState()
    val escolher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) vm.importarModelo(uri)
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (cfg.setupFeito) {
            TextButton(onClick = { vm.tela.value = Tela.CHAT }) { Text("← Voltar") }
        }
        Text("Trocar o cérebro do ${Marca.NOME} (opcional)", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(
            "O ${Marca.NOME} já vem com uma IA dentro e funciona sem você fazer nada. " +
                "Esta tela é só para quem quiser trocar por outro modelo (.task) por conta própria.",
            fontSize = 15.sp
        )
        Card(colors = CardDefaults.cardColors(containerColor = Cores.Superficie)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Como conseguir o arquivo", fontWeight = FontWeight.Bold)
                Text("1. Abra o site huggingface.co e procure por \"Gemma 3n E2B\" no formato .task (MediaPipe / LiteRT).")
                Text("2. Pode ser preciso criar uma conta grátis e aceitar a licença do modelo.")
                Text("3. Baixe o arquivo e volte aqui.")
                Text(
                    "Recomendado: Gemma 3n E2B. Ele usa uns 3 a 4 GB de RAM e é o que deixa o ${Marca.NOME} VER fotos. " +
                        "Se o celular ficar lento, use um modelo menor (Gemma 3 1B), mas ele não enxerga imagens.",
                    color = Cores.Cinza,
                    fontSize = 13.sp
                )
            }
        }

        when (val e = estado) {
            is EstadoModelo.Copiando -> {
                Text("Copiando o modelo para o app… ${e.pct}%")
                LinearProgressIndicator(progress = { e.pct / 100f }, modifier = Modifier.fillMaxWidth())
                Text("Isso pode levar alguns minutos. Não feche o app.", fontSize = 13.sp)
            }
            EstadoModelo.Carregando -> {
                Text("Carregando a IA na memória…")
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
            EstadoModelo.Pronto -> {
                Text("✅ Modelo pronto!", fontWeight = FontWeight.Bold)
                Button(onClick = { vm.tela.value = Tela.CHAT }, modifier = Modifier.fillMaxWidth()) {
                    Text("Ir para o chat")
                }
            }
            is EstadoModelo.Erro -> {
                Text("⚠️ ${e.msg}", color = Color(0xFFFFB4AB))
            }
            EstadoModelo.Nenhum -> {}
        }

        val ocupado = estado is EstadoModelo.Copiando || estado == EstadoModelo.Carregando
        Button(
            onClick = { escolher.launch(arrayOf("*/*")) },
            enabled = !ocupado,
            modifier = Modifier.fillMaxWidth()
        ) { Text("📂 Escolher arquivo do modelo") }

        OutlinedButton(
            onClick = { vm.tela.value = Tela.CHAT },
            enabled = !ocupado,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Pular por enquanto") }
    }
}

// ============================================================ CHAT

@Composable
fun TelaChat(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val cfg by vm.cfg.collectAsState()
    val msgs by vm.mensagens.collectAsState()
    val gerando by vm.gerando.collectAsState()
    val ouvindo by vm.ouvindo.collectAsState()
    val entrada by vm.entrada.collectAsState()
    val aviso by vm.aviso.collectAsState()
    val estado by vm.estadoModelo.collectAsState()
    val modo by vm.modo.collectAsState()
    val modoVoz by vm.modoVoz.collectAsState()
    val foto by vm.foto.collectAsState()
    val visao by vm.visaoDisponivel.collectAsState()
    val lista = rememberLazyListState()

    var verSite by remember { mutableStateOf<String?>(null) }
    var aposMic by remember { mutableStateOf<(() -> Unit)?>(null) }

    val pedirMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            aposMic?.invoke()
        } else {
            vm.aviso.value = "Sem a permissão do microfone eu não consigo te ouvir."
        }
    }

    var fotoUri by remember { mutableStateOf<Uri?>(null) }
    val tirarFoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = fotoUri
        if (ok && u != null) vm.anexarFoto(u)
    }
    val galeria = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) vm.anexarFoto(uri)
    }

    fun comMicrofone(acao: () -> Unit) {
        if (!PoliticaDeControle.microfonePermitido(cfg)) {
            vm.aviso.value = "O microfone está desligado em ⚙️ Configurações."
            return
        }
        val tem = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (tem) {
            acao()
        } else {
            aposMic = acao
            pedirMic.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(msgs.size, msgs.lastOrNull()?.text?.length) {
        if (msgs.isNotEmpty()) lista.scrollToItem(msgs.lastIndex)
    }

    val arquivos = remember(msgs) { Arquivos.doProjeto(msgs) }

    val subtitulo = when {
        gerando -> "pensando…"
        estado is EstadoModelo.Pronto -> if (visao) "pronto • vê fotos 👁" else "pronto"
        estado is EstadoModelo.Copiando -> "preparando a IA…"
        estado is EstadoModelo.Carregando -> "carregando a IA…"
        estado is EstadoModelo.Erro -> "erro no modelo"
        else -> "sem modelo carregado"
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
    ) {
        // ---- topo
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { vm.tela.value = Tela.HISTORICO }) { Text("☰", fontSize = 20.sp) }
            Image(
                painter = painterResource(R.drawable.kalberdex_capa),
                contentDescription = null,
                modifier = Modifier.size(34.dp).clip(CircleShape)
            )
            Spacer(Modifier.padding(horizontal = 5.dp))
            Column(Modifier.weight(1f)) {
                Text(cfg.nomeIa, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Cores.Destaque)
                Text(subtitulo, fontSize = 12.sp, color = Cores.Cinza)
            }
            TextButton(onClick = { vm.tela.value = Tela.ATELIE }) { Text("🎨", fontSize = 20.sp) }
            TextButton(onClick = { vm.atualizarMemoria(); vm.tela.value = Tela.MEMORIA }) { Text("🧠", fontSize = 20.sp) }
            TextButton(onClick = { vm.tela.value = Tela.AJUSTES }) { Text("⚙️", fontSize = 20.sp) }
        }

        // ---- modos
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = modo == Modo.CONVERSA,
                onClick = { vm.modo.value = Modo.CONVERSA },
                label = { Text("💬 Conversa") }
            )
            FilterChip(
                selected = modo == Modo.PROGRAMADOR,
                onClick = { vm.modo.value = Modo.PROGRAMADOR },
                label = { Text("💻 Programador") }
            )
            FilterChip(
                selected = modoVoz,
                onClick = {
                    if (modoVoz) {
                        vm.pararModoVoz()
                    } else {
                        comMicrofone { vm.iniciarModoVoz(ComandoDoChefe.deToque("botao-conversa-por-voz")) }
                    }
                },
                label = { Text("🗣️ Voz") }
            )
            AssistChip(
                onClick = { vm.alternarInternet() },
                label = { Text(if (cfg.internet) "Internet 🌐" else "Offline 🔒") }
            )
        }

        // ---- avisos
        if (aviso != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(Color(0xFF2A3A12))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(aviso ?: "", modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = { vm.aviso.value = null }) { Text("OK") }
            }
        }
        if (ouvindo || modoVoz) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(Cores.Alerta)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (modoVoz) "🗣️ Conversa por voz ligada — o ${Marca.NOME} ouve e responde" else "🎙️ Microfone ligado — ouvindo você",
                    modifier = Modifier.weight(1f),
                    color = Color.White
                )
                TextButton(onClick = { if (modoVoz) vm.pararModoVoz() else vm.pararDeOuvir() }) {
                    Text("PARAR", color = Color.White)
                }
            }
        }
        if (estado is EstadoModelo.Erro) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(Color(0xFF3A1212))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("A IA local não carregou.", modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = { vm.refazerModeloEmbutido() }) { Text("Tentar de novo") }
            }
        }
        if (estado is EstadoModelo.Copiando) {
            val pct = (estado as EstadoModelo.Copiando).pct
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(Color(0xFF12301A))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text("Preparando a IA pela primeira vez… $pct%  (só acontece uma vez, não feche o app)", fontSize = 13.sp)
                LinearProgressIndicator(progress = { pct / 100f }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            }
        }
        if (estado is EstadoModelo.Carregando) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(Color(0xFF12301A))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Text("Acordando a IA…", fontSize = 13.sp)
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            }
        }
        if (estado is EstadoModelo.Nenhum) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp)
                    .background(Color(0xFF12301A))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Escolha um modelo de IA para o ${Marca.NOME} poder pensar.", modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = { vm.tela.value = Tela.MODELO }) { Text("Escolher") }
            }
        }

        // ---- barra do projeto (modo programador)
        if (modo == Modo.PROGRAMADOR && arquivos.isNotEmpty()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(onClick = {
                    try {
                        val zip = Arquivos.criarZip(ctx, vm.nomeDoProjeto(), arquivos)
                        if (Arquivos.salvarEmDownloads(ctx, zip, "application/zip")) {
                            vm.aviso.value = "📦 ZIP salvo na pasta Downloads (${arquivos.size} arquivos)."
                        }
                        Arquivos.compartilhar(ctx, zip, "application/zip")
                    } catch (e: Exception) {
                        vm.aviso.value = "Não consegui criar o ZIP: ${e.message}"
                    }
                }) { Text("📦 ZIP (${arquivos.size})") }
                val site = remember(arquivos) { Arquivos.montarSite(arquivos) }
                if (site != null) {
                    OutlinedButton(onClick = { verSite = site }) { Text("👁 Ver site") }
                }
            }
        }

        // ---- mensagens
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (msgs.isEmpty()) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Oi, ${cfg.nomeUsuario}! 👋", fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text("Sou ${cfg.nomeIa}. O que vamos fazer hoje?", fontSize = 16.sp)
                    Spacer(Modifier.height(18.dp))
                    val sugestoes = if (modo == Modo.PROGRAMADOR) {
                        listOf(
                            "Crie um site de uma barbearia com página inicial, serviços e contato",
                            "Crie uma calculadora em HTML, CSS e JavaScript",
                            "Crie uma loja virtual simples com carrinho"
                        )
                    } else {
                        listOf(
                            "Pesquise sobre inteligência artificial",
                            "Lembre que meu time favorito é o Flamengo",
                            "Me explique algo de forma simples"
                        )
                    }
                    sugestoes.forEach { s ->
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Cores.Superficie,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable { vm.entrada.value = s }
                        ) {
                            Text(s, modifier = Modifier.padding(14.dp))
                        }
                    }
                }
            } else {
                LazyColumn(
                    state = lista,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(msgs.size) { i -> Balao(msgs[i]) }
                }
            }
        }

        // ---- atalhos
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AssistChip(onClick = { vm.pedirIdeias() }, label = { Text("💡 Ideias") })
            AssistChip(onClick = { vm.novaConversa() }, label = { Text("➕ Nova") })
        }

        // ---- foto anexada
        val fotoAtual = foto
        if (fotoAtual != null) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    bitmap = fotoAtual.asImageBitmap(),
                    contentDescription = "Foto anexada",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(56.dp).clip(RoundedCornerShape(10.dp))
                )
                Spacer(Modifier.padding(horizontal = 6.dp))
                Text("Foto pronta para enviar", modifier = Modifier.weight(1f), fontSize = 13.sp)
                TextButton(onClick = { vm.removerFoto() }) { Text("✕") }
            }
        }

        // ---- entrada
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            TextButton(onClick = {
                val uri = vm.novaFotoUri(ComandoDoChefe.deToque("botao-camera"))
                if (uri != null) {
                    fotoUri = uri
                    tirarFoto.launch(uri)
                }
            }) { Text("📷", fontSize = 22.sp) }

            TextButton(onClick = { galeria.launch("image/*") }) { Text("🖼", fontSize = 22.sp) }

            TextButton(onClick = {
                if (ouvindo) {
                    if (modoVoz) vm.pararModoVoz() else vm.pararDeOuvir()
                } else {
                    comMicrofone { vm.ouvir(ComandoDoChefe.deToque("botao-microfone")) }
                }
            }) { Text(if (ouvindo) "⏹" else "🎤", fontSize = 22.sp) }

            OutlinedTextField(
                value = entrada,
                onValueChange = { vm.entrada.value = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Fale com ${cfg.nomeIa}…") },
                maxLines = 4,
                shape = RoundedCornerShape(22.dp)
            )
            Spacer(Modifier.padding(horizontal = 3.dp))
            Button(
                onClick = { if (gerando && entrada.isBlank()) vm.parar() else vm.enviarEntrada() },
                shape = RoundedCornerShape(22.dp)
            ) { Text(if (gerando && entrada.isBlank()) "⏹" else "➤", fontSize = 18.sp) }
            Spacer(Modifier.padding(horizontal = 2.dp))
        }
    }

    val paginaSite = verSite
    if (paginaSite != null) {
        VisualizadorSite(paginaSite) { verSite = null }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun VisualizadorSite(html: String, aoFechar: () -> Unit) {
    Dialog(onDismissRequest = aoFechar) {
        Surface(shape = RoundedCornerShape(16.dp), color = Cores.Superficie, modifier = Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Prévia do site", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    TextButton(onClick = aoFechar) { Text("Fechar ✕") }
                }
                AndroidView(
                    factory = { c ->
                        WebView(c).apply {
                            settings.javaScriptEnabled = true
                            settings.allowFileAccess = false
                            settings.allowContentAccess = false
                            setBackgroundColor(android.graphics.Color.WHITE)
                        }
                    },
                    update = { w ->
                        if (w.tag != html) {
                            w.tag = html
                            w.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
                        }
                    },
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
            }
        }
    }
}

@Composable
fun Balao(m: Msg) {
    val usuario = m.role == "user"
    val miniatura = remember(m.foto) {
        m.foto?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() }
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (usuario) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (usuario) Cores.BalaoUsuario else Cores.BalaoIa,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 330.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                if (miniatura != null) {
                    Image(
                        bitmap = miniatura,
                        contentDescription = "Foto enviada",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.widthIn(max = 240.dp).clip(RoundedCornerShape(10.dp))
                    )
                    Spacer(Modifier.height(6.dp))
                }
                SelectionContainer {
                    Text(
                        text = if (m.text.isEmpty()) "…" else m.text,
                        color = Color.White,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

// ============================================================ HISTÓRICO

@Composable
fun TelaHistorico(vm: ChatViewModel) {
    val conversas by vm.conversas.collectAsState()
    val formato = remember { SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")) }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.tela.value = Tela.CHAT }) { Text("← Voltar") }
            Text("Conversas", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(onClick = { vm.novaConversa() }) { Text("➕ Nova") }
        }
        Spacer(Modifier.height(8.dp))
        if (conversas.isEmpty()) {
            Text("Ainda não tem conversas salvas.", color = Cores.Cinza)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(conversas, key = { it.id }) { c ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Cores.Superficie),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { vm.abrirConversa(c.id) }
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.titulo, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(
                                formato.format(Date(c.atualizadoEm)) + " • " + c.msgs.size + " mensagens",
                                fontSize = 12.sp,
                                color = Cores.Cinza
                            )
                        }
                        TextButton(onClick = { vm.apagarConversa(c.id) }) { Text("🗑") }
                    }
                }
            }
        }
    }
}

// ============================================================ MEMÓRIA

@Composable
fun TelaMemoria(vm: ChatViewModel) {
    val fatos by vm.memoriaLista.collectAsState()
    val estudando by vm.estudando.collectAsState()
    val aviso by vm.aviso.collectAsState()
    var novo by remember { mutableStateOf("") }
    var tema by remember { mutableStateOf("") }
    val formato = remember { SimpleDateFormat("dd/MM HH:mm", Locale("pt", "BR")) }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.tela.value = Tela.CHAT }) { Text("← Voltar") }
            Text("🧠 Memória do ${Marca.NOME}", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            "Tudo o que você ensina e tudo o que ele estuda fica guardado aqui, no seu celular. " +
                "Antes de responder, ele procura nesta memória.",
            fontSize = 13.sp,
            color = Cores.Cinza
        )
        if (aviso != null) {
            Spacer(Modifier.height(6.dp))
            Text(aviso ?: "", color = Cores.Destaque, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = novo,
            onValueChange = { novo = it },
            label = { Text("Ensinar algo ao ${Marca.NOME}") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3
        )
        Button(
            onClick = { vm.ensinar(novo); novo = "" },
            enabled = novo.trim().length >= 3,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Guardar na memória") }
        Spacer(Modifier.height(6.dp))
        OutlinedTextField(
            value = tema,
            onValueChange = { tema = it },
            label = { Text("Estudar um tema na internet") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { vm.estudar(tema); tema = "" },
            enabled = tema.trim().length >= 2 && !estudando,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (estudando) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            else Text("🔎 Estudar agora")
        }
        Spacer(Modifier.height(8.dp))
        Text("${fatos.size} coisas na memória", fontWeight = FontWeight.Bold, color = Cores.Destaque)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.weight(1f)) {
            items(fatos, key = { it.id }) { f ->
                Card(colors = CardDefaults.cardColors(containerColor = Cores.Superficie)) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(f.texto.take(260), fontSize = 14.sp)
                            Text(
                                f.fonte.take(40) + " • " + formato.format(Date(f.em)),
                                fontSize = 11.sp,
                                color = Cores.Cinza
                            )
                        }
                        TextButton(onClick = { vm.esquecer(f.id) }) { Text("🗑") }
                    }
                }
            }
        }
    }
}

// ============================================================ CONFIGURAÇÕES

@Composable
fun TelaAjustes(vm: ChatViewModel) {
    val atual by vm.cfg.collectAsState()
    var c by remember { mutableStateOf(atual) }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { vm.tela.value = Tela.CHAT }) { Text("← Voltar") }
            Text("Configurações", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }

        Text(Marca.CREDITO, fontSize = 13.sp, color = Cores.Cinza)
        Text("Personalidade", fontWeight = FontWeight.Bold, color = Cores.Destaque)
        OutlinedTextField(
            value = Marca.NOME,
            onValueChange = { },
            readOnly = true,
            label = { Text("Nome da IA") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = Marca.MODELO,
            onValueChange = { },
            readOnly = true,
            label = { Text("Modelo local") },
            supportingText = { Text("Embutido no aplicativo Android.") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = c.nomeUsuario,
            onValueChange = { c = c.copy(nomeUsuario = it) },
            label = { Text("Como ele te chama") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = c.promptSistema,
            onValueChange = { c = c.copy(promptSistema = it) },
            label = { Text("Instruções do modo Conversa") },
            minLines = 5,
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            "Use {nome} e {usuario} no texto: o app troca pelos nomes acima.",
            fontSize = 12.sp,
            color = Cores.Cinza
        )
        TextButton(onClick = { c = c.copy(promptSistema = PROMPT_PADRAO) }) { Text("Restaurar instruções padrão") }

        Text("Controle do chefe", fontWeight = FontWeight.Bold, color = Cores.Destaque)
        LinhaSwitch("Permitir microfone", "Só liga quando você toca no 🎤 ou em 🗣️ Voz.", c.microfone) { c = c.copy(microfone = it) }
        LinhaSwitch("Permitir câmera", "Só abre quando você toca no 📷.", c.camera) { c = c.copy(camera = it) }
        LinhaSwitch("Ler respostas em voz alta", "O ${Marca.NOME} fala as respostas do modo Conversa.", c.falarRespostas) { c = c.copy(falarRespostas = it) }

        Text("Internet", fontWeight = FontWeight.Bold, color = Cores.Destaque)
        LinhaSwitch(
            "Pesquisar e aprender na internet",
            "Sem API e sem chave: ele abre a Wikipédia e links que você mandar, lê e guarda na memória. Desligado: nada sai do celular.",
            c.internet
        ) { c = c.copy(internet = it) }

        Text("Desempenho da IA local", fontWeight = FontWeight.Bold, color = Cores.Destaque)
        Text("Criatividade: ${"%.1f".format(Locale.US, c.temperatura)}")
        Slider(
            value = c.temperatura,
            onValueChange = { c = c.copy(temperatura = it) },
            valueRange = 0.1f..1.0f
        )
        Text("Tamanho máximo da conversa (tokens)")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(2048, 4096, 6144).forEach { n ->
                FilterChip(
                    selected = c.maxTokens == n,
                    onClick = { c = c.copy(maxTokens = n) },
                    label = { Text("$n") }
                )
            }
        }
        Text(
            "Mais tokens = lembra mais e escreve códigos maiores, mas usa mais memória e fica mais lento. " +
                "Ao mudar, o modelo é recarregado.",
            fontSize = 12.sp,
            color = Cores.Cinza
        )

        Button(
            onClick = {
                vm.salvarConfigCompleta(c)
                vm.tela.value = Tela.CHAT
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Salvar") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun LinhaSwitch(titulo: String, sub: String, marcado: Boolean, aoMudar: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(titulo, fontWeight = FontWeight.Medium)
            Text(sub, fontSize = 12.sp, color = Cores.Cinza)
        }
        Switch(checked = marcado, onCheckedChange = aoMudar)
    }
}
