package com.meuapp.iaoffline

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Guarda as conversas num arquivo JSON dentro do armazenamento interno do app. */
class ChatStore(private val ctx: Context) {

    private fun arquivo(): File = File(ctx.filesDir, "conversas_hamk.json")

    fun carregar(): List<Conversa> {
        return try {
            val f = arquivo()
            if (!f.exists()) {
                emptyList()
            } else {
                val arr = JSONArray(f.readText())
                val saida = ArrayList<Conversa>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val ms = o.getJSONArray("msgs")
                    val msgs = ArrayList<Msg>()
                    for (j in 0 until ms.length()) {
                        val m = ms.getJSONObject(j)
                        val foto = m.optString("foto", "")
                        msgs.add(Msg(m.getString("role"), m.getString("text"), if (foto.isBlank()) null else foto))
                    }
                    saida.add(
                        Conversa(
                            o.getString("id"),
                            o.getString("titulo"),
                            msgs,
                            o.optLong("em", 0L)
                        )
                    )
                }
                saida
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun salvar(lista: List<Conversa>) {
        try {
            val arr = JSONArray()
            for (c in lista) {
                val ms = JSONArray()
                for (m in c.msgs) {
                    val o = JSONObject().put("role", m.role).put("text", m.text)
                    if (m.foto != null) o.put("foto", m.foto)
                    ms.put(o)
                }
                arr.put(
                    JSONObject()
                        .put("id", c.id)
                        .put("titulo", c.titulo)
                        .put("em", c.atualizadoEm)
                        .put("msgs", ms)
                )
            }
            arquivo().writeText(arr.toString())
        } catch (e: Exception) {
            // sem espaço ou outro erro: ignora para não fechar o app
        }
    }
}
