package com.meuapp.iaoffline

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class ArquivoGerado(val caminho: String, val conteudo: String)

/** Tudo sobre arquivos que o Kalberdex 01 gera: ler os blocos de código, montar o ZIP, visualizar o site e compartilhar. */
object Arquivos {

    private val reNome = Regex("([A-Za-z0-9_\\-./]+\\.[A-Za-z0-9]{1,6})")

    private val extensoes = setOf(
        "html", "css", "js", "json", "txt", "md", "py", "php", "kt", "java", "xml", "svg", "ts",
        "tsx", "jsx", "sql", "sh", "yml", "yaml", "csv", "c", "cpp", "h", "go", "rs", "rb", "gradle",
        "kts", "properties", "htaccess", "ini", "toml", "vue", "scss"
    )

    private fun normalizarNome(bruto: String): String? {
        var n = bruto.trim().trim('`', '*', '"', '\'', ':')
        while (n.startsWith("./")) n = n.substring(2)
        n = n.trimStart('/')
        if (n.isEmpty() || n.length > 120 || n.contains("..")) return null
        val ext = n.substringAfterLast('.', "").lowercase()
        if (ext !in extensoes) return null
        return n
    }

    private fun nomeNaLinha(linha: String): String? {
        val limpo = linha.trim('#', '*', '`', ' ', ':').trim()
        val m = reNome.find(limpo) ?: return null
        val baixo = limpo.lowercase()
        val ehTitulo = linha.startsWith("#") || linha.startsWith("**") || linha.startsWith("`") ||
            baixo.startsWith("arquivo") || baixo.startsWith("file") || limpo == m.value
        return if (ehTitulo && limpo.length < 100) normalizarNome(m.value) else null
    }

    private fun nomeNaInfo(info: String): String? {
        for (m in reNome.findAll(info)) {
            val n = normalizarNome(m.value)
            if (n != null) return n
        }
        return null
    }

    private fun padraoPorLinguagem(info: String, corpo: String, usados: Set<String>): String? {
        val lang = info.trim().lowercase().substringBefore(' ').substringBefore(':')
        val candidato = when (lang) {
            "html" -> if (corpo.contains("<html", ignoreCase = true) || corpo.contains("<!doctype", ignoreCase = true)) "index.html" else null
            "css" -> "style.css"
            "js", "javascript" -> "script.js"
            "python", "py" -> "main.py"
            "php" -> "index.php"
            else -> null
        }
        return if (candidato != null && candidato !in usados) candidato else null
    }

    /** Lê os blocos de código de um texto e devolve os arquivos que achou (nome + conteúdo). */
    fun extrair(texto: String): List<ArquivoGerado> {
        val saida = LinkedHashMap<String, String>()
        val linhas = texto.split("\n")
        var i = 0
        var ultimoNome: String? = null
        while (i < linhas.size) {
            val t = linhas[i].trim()
            if (t.startsWith("```")) {
                val info = t.removePrefix("```").trim()
                val corpo = StringBuilder()
                i++
                while (i < linhas.size && !linhas[i].trim().startsWith("```")) {
                    corpo.append(linhas[i]).append("\n")
                    i++
                }
                var nome = nomeNaInfo(info) ?: ultimoNome
                if (nome == null) nome = padraoPorLinguagem(info, corpo.toString(), saida.keys)
                if (nome != null && corpo.isNotBlank()) saida[nome] = corpo.toString().trimEnd() + "\n"
                ultimoNome = null
            } else if (t.isNotEmpty()) {
                ultimoNome = nomeNaLinha(t)
            }
            i++
        }
        return saida.map { ArquivoGerado(it.key, it.value) }
    }

    /** Junta os arquivos de todas as respostas do Kalberdex 01 (o mais novo vence se o nome se repetir). */
    fun doProjeto(msgs: List<Msg>): List<ArquivoGerado> {
        val mapa = LinkedHashMap<String, String>()
        for (m in msgs) {
            if (m.role != "assistant") continue
            for (a in extrair(m.text)) mapa[a.caminho] = a.conteudo
        }
        return mapa.map { ArquivoGerado(it.key, it.value) }
    }

    /** Monta uma página única (com CSS e JS embutidos) para visualizar o site dentro do app. */
    fun montarSite(arqs: List<ArquivoGerado>): String? {
        val indice = arqs.firstOrNull { it.caminho.equals("index.html", ignoreCase = true) }
            ?: arqs.firstOrNull { it.caminho.endsWith(".html", ignoreCase = true) }
            ?: return null
        var html = indice.conteudo
        for (a in arqs) {
            val nome = a.caminho.substringAfterLast('/')
            if (a.caminho.endsWith(".css", ignoreCase = true)) {
                val re = Regex("<link[^>]*href=[\"'][^\"']*" + Regex.escape(nome) + "[\"'][^>]*>", RegexOption.IGNORE_CASE)
                html = re.replace(html) { "<style>\n" + a.conteudo + "\n</style>" }
            } else if (a.caminho.endsWith(".js", ignoreCase = true)) {
                val re = Regex("<script[^>]*src=[\"'][^\"']*" + Regex.escape(nome) + "[\"'][^>]*>\\s*</script>", RegexOption.IGNORE_CASE)
                html = re.replace(html) { "<script>\n" + a.conteudo + "\n</script>" }
            }
        }
        return html
    }

    private fun pastaExports(ctx: Context): File = File(ctx.cacheDir, "exports").apply { mkdirs() }

    fun nomeSeguro(base: String): String =
        base.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(40).ifBlank { "projeto-kalberdex" }

    fun criarZip(ctx: Context, nomeBase: String, arqs: List<ArquivoGerado>): File {
        val destino = File(pastaExports(ctx), nomeSeguro(nomeBase) + ".zip")
        ZipOutputStream(FileOutputStream(destino)).use { z ->
            for (a in arqs) {
                z.putNextEntry(ZipEntry(a.caminho))
                z.write(a.conteudo.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            z.putNextEntry(ZipEntry("LEIA-ME.txt"))
            z.write("Projeto gerado pelo Kalberdex 01 (${Marca.CREDITO}).\nArquivos: ${arqs.size}\n".toByteArray(Charsets.UTF_8))
            z.closeEntry()
        }
        return destino
    }

    fun salvarTexto(ctx: Context, nome: String, conteudo: String): File {
        val f = File(pastaExports(ctx), nome)
        f.writeText(conteudo)
        return f
    }

    fun pastaDeExportacao(ctx: Context): File = pastaExports(ctx)

    fun compartilhar(ctx: Context, arq: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", arq)
        val envio = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val escolha = Intent.createChooser(envio, "Enviar / salvar").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(escolha)
    }

    /** Copia o arquivo para a pasta Downloads (Android 10 ou mais novo). */
    fun salvarEmDownloads(ctx: Context, arq: File, mime: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val valores = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, arq.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
            if (uri == null) {
                false
            } else {
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    arq.inputStream().use { it.copyTo(out) }
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    /** Salva uma imagem PNG na galeria, pasta Pictures/Kalberdex 01 (Android 10 ou mais novo). */
    fun salvarNaGaleria(ctx: Context, arq: File): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val valores = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, arq.name)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Kalberdex")
            }
            val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, valores)
            if (uri == null) {
                false
            } else {
                ctx.contentResolver.openOutputStream(uri)?.use { out ->
                    arq.inputStream().use { it.copyTo(out) }
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }
}
