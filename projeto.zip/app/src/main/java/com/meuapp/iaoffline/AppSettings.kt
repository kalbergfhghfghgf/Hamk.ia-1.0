package com.meuapp.iaoffline

import android.content.Context
import android.content.SharedPreferences

class AppSettings(ctx: Context) {

    private val sp: SharedPreferences = ctx.getSharedPreferences("config_hamk", Context.MODE_PRIVATE)

    fun carregar(): Config {
        val d = Config()
        return Config(
            nomeIa = Marca.NOME,
            nomeUsuario = sp.getString("nomeUsuario", d.nomeUsuario) ?: d.nomeUsuario,
            promptSistema = sp.getString("promptSistema", d.promptSistema) ?: d.promptSistema,
            internet = sp.getBoolean("internet", d.internet),
            microfone = sp.getBoolean("microfone", d.microfone),
            camera = sp.getBoolean("camera", d.camera),
            falarRespostas = sp.getBoolean("falarRespostas", d.falarRespostas),
            maxTokens = sp.getInt("maxTokens", d.maxTokens),
            temperatura = sp.getFloat("temperatura", d.temperatura).coerceIn(0.1f, 1.0f),
            setupFeito = sp.getBoolean("setupFeito", d.setupFeito),
            caminhoModelo = sp.getString("caminhoModelo", d.caminhoModelo) ?: d.caminhoModelo,
            nomeModelo = sp.getString("nomeModelo", d.nomeModelo) ?: d.nomeModelo
        )
    }

    fun temaIndice(): Int = sp.getInt("tema", 0)
    fun salvarTema(i: Int) { sp.edit().putInt("tema", i).apply() }
    fun adminLiberado(): Boolean = sp.getBoolean("admin", false)
    fun salvarAdmin(v: Boolean) { sp.edit().putBoolean("admin", v).apply() }

    fun salvar(c: Config) {
        sp.edit()
            .putString("nomeIa", c.nomeIa)
            .putString("nomeUsuario", c.nomeUsuario)
            .putString("promptSistema", c.promptSistema)
            .putBoolean("internet", c.internet)
            .putBoolean("microfone", c.microfone)
            .putBoolean("camera", c.camera)
            .putBoolean("falarRespostas", c.falarRespostas)
            .putInt("maxTokens", c.maxTokens)
            .putFloat("temperatura", c.temperatura)
            .putBoolean("setupFeito", c.setupFeito)
            .putString("caminhoModelo", c.caminhoModelo)
            .putString("nomeModelo", c.nomeModelo)
            .apply()
    }
}
