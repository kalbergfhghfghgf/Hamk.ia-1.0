package com.meuapp.iaoffline

import android.content.Context
import android.content.SharedPreferences

class AppSettings(ctx: Context) {

    private val sp: SharedPreferences = ctx.getSharedPreferences("config_hamk", Context.MODE_PRIVATE)

    fun carregar(): Config {
        val d = Config()
        return Config(
            nomeIa = sp.getString("nomeIa", d.nomeIa) ?: d.nomeIa,
            nomeUsuario = sp.getString("nomeUsuario", d.nomeUsuario) ?: d.nomeUsuario,
            promptSistema = sp.getString("promptSistema", d.promptSistema) ?: d.promptSistema,
            internet = sp.getBoolean("internet", d.internet),
            microfone = sp.getBoolean("microfone", d.microfone),
            camera = sp.getBoolean("camera", d.camera),
            falarRespostas = sp.getBoolean("falarRespostas", d.falarRespostas),
            maxTokens = sp.getInt("maxTokens", d.maxTokens),
            temperatura = sp.getFloat("temperatura", d.temperatura),
            setupFeito = sp.getBoolean("setupFeito", d.setupFeito),
            caminhoModelo = sp.getString("caminhoModelo", d.caminhoModelo) ?: d.caminhoModelo,
            nomeModelo = sp.getString("nomeModelo", d.nomeModelo) ?: d.nomeModelo
        )
    }

    fun salvar(c: Config) {
        sp.edit()
            .putString("nomeIa", c.nomeIa)
            .putString("nomeUsuario", c.nomeUsuario)
            .putString("promptSistema", c.promptSistema)
            .putBoolean("internet", c.internet)
            .putBoolean("microfone", c.microfone)
            .putBoolean("camera", c.camera)
            .putBoolean("falarRespostas", c.falarRespostas)
            .putInt("maxTokens", c.maxTokens)
            .putFloat("temperatura", c.temperatura)
            .putBoolean("setupFeito", c.setupFeito)
            .putString("caminhoModelo", c.caminhoModelo)
            .putString("nomeModelo", c.nomeModelo)
            .apply()
    }
}
