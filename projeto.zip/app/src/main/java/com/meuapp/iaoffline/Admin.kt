package com.meuapp.iaoffline

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.security.MessageDigest

/**
 * Área do administrador. Para liberar: digite o código secreto na caixa de mensagem do chat e envie.
 * O código não fica escrito no app (só a "impressão digital" dele).
 */
object Admin {
    private const val HASH = "8e4b56a737d173fa65399063decf8b0a87fc7c70db4559bd82728904e7eed14e"

    var liberado by mutableStateOf(false)
        private set

    fun iniciar(ctx: Context) {
        liberado = AppSettings(ctx).adminLiberado()
    }

    private fun hash(t: String): String =
        MessageDigest.getInstance("SHA-256").digest(t.toByteArray()).joinToString("") { "%02x".format(it) }

    fun tentar(ctx: Context, texto: String): Boolean {
        if (texto.length > 40 || hash(texto.trim()) != HASH) return false
        liberado = true
        AppSettings(ctx).salvarAdmin(true)
        return true
    }

    fun bloquear(ctx: Context) {
        liberado = false
        AppSettings(ctx).salvarAdmin(false)
    }
}
