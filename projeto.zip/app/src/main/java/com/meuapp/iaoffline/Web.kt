package com.meuapp.iaoffline

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

/**
 * Acesso à internet do Hamk, SEM API de IA e SEM chave de ninguém:
 * ele só abre páginas públicas (Wikipédia e os links que você mandar) e lê o texto.
 */
object Web {

    data class Pagina(val titulo: String, val texto: String, val url: String)

    fun conectado(ctx: Context): Boolean {
        return try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val rede = cm.activeNetwork
            if (rede == null) {
                false
            } else {
                val cap = cm.getNetworkCapabilities(rede)
                cap != null && cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun baixar(endereco: String, limite: Int = 500_000): String {
        val con = URL(endereco).openConnection() as HttpURLConnection
        try {
            con.connectTimeout = 10000
            con.readTimeout = 15000
            con.instanceFollowRedirects = true
            con.setRequestProperty("User-Agent", "Hamk/1.0 (app Android pessoal)")
            con.setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
            val codigo = con.responseCode
            if (codigo !in 200..299) throw IOException("HTTP $codigo")
            return con.inputStream.use { ins ->
                val buf = ByteArray(limite)
                var total = 0
                while (total < limite) {
                    val n = ins.read(buf, total, limite - total)
                    if (n < 0) break
                    total += n
                }
                String(buf, 0, total, Charsets.UTF_8)
            }
        } finally {
            con.disconnect()
        }
    }

    fun pesquisarWikipedia(consulta: String): Pagina? {
        val q = URLEncoder.encode(consulta, "UTF-8")
        val busca = JSONObject(
            baixar("https://pt.wikipedia.org/w/api.php?action=query&list=search&srsearch=$q&srlimit=1&format=json&utf8=1")
        )
        val itens = busca.getJSONObject("query").getJSONArray("search")
        if (itens.length() == 0) return null
        val titulo = itens.getJSONObject(0).getString("title")
        val t = URLEncoder.encode(titulo, "UTF-8")
        val ext = JSONObject(
            baixar("https://pt.wikipedia.org/w/api.php?action=query&prop=extracts&exintro=1&explaintext=1&redirects=1&titles=$t&format=json&utf8=1")
        )
        val paginas = ext.getJSONObject("query").getJSONObject("pages")
        val chave = paginas.keys().next()
        val texto = paginas.getJSONObject(chave).optString("extract", "").trim()
        if (texto.isBlank()) return null
        return Pagina(titulo, texto.take(1500), "https://pt.wikipedia.org/wiki/" + titulo.replace(' ', '_'))
    }

    fun lerPagina(endereco: String): Pagina {
        if (!endereco.startsWith("https://")) throw IOException("Só abro links https.")
        val html = baixar(endereco)
        val opcoes = setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE)
        val titulo = Regex("<title[^>]*>(.*?)</title>", opcoes).find(html)?.groupValues?.get(1)?.trim()
            ?: endereco
        var t = Regex("<script.*?</script>", opcoes).replace(html, " ")
        t = Regex("<style.*?</style>", opcoes).replace(t, " ")
        t = Regex("<[^>]+>").replace(t, " ")
        t = t.replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"")
            .replace("&lt;", "<").replace("&gt;", ">")
        t = Regex("\\s+").replace(t, " ").trim()
        return Pagina(titulo.take(120), t.take(3000), endereco)
    }

    fun extrairUrl(texto: String): String? {
        val m = Regex("https?://\\S+").find(texto) ?: return null
        return m.value.trimEnd('.', ',', ')', ';', '!', '?')
    }

    private val GATILHOS = listOf(
        "pesquise", "pesquisa sobre", "busque", "procure", "na internet", "na web",
        "o que é", "o que são", "o que foi", "quem é", "quem foi", "quem são",
        "me fale sobre", "fale sobre", "o que significa", "aprenda sobre", "estude sobre"
    )

    fun querPesquisar(texto: String): Boolean {
        val b = texto.lowercase(Locale("pt", "BR"))
        return GATILHOS.any { b.contains(it) }
    }

    fun limparConsulta(texto: String): String {
        var b = texto.lowercase(Locale("pt", "BR"))
        for (g in GATILHOS) b = b.replace(g, " ")
        b = b.replace(Regex("[?!.,:;]"), " ")
        b = b.replace(Regex("\\b(para mim|por favor|sobre|de|do|da|um|uma|o|a)\\b"), " ")
        b = Regex("\\s+").replace(b, " ").trim()
        return if (b.length >= 3) b else texto.trim()
    }
}
