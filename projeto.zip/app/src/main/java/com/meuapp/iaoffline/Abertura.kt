package com.meuapp.iaoffline

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin
import kotlin.random.Random

/** Tela de abertura: logo, anéis girando, partículas de luz e brilho pulsando. */
@Composable
fun TelaAbertura(mensagem: String) {
    val giro = rememberInfiniteTransition(label = "giro")
    val a1 by giro.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "anelFora"
    )
    val a2 by giro.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(3600, easing = LinearEasing)),
        label = "anelDentro"
    )
    val pulso by giro.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "pulso"
    )
    val fase by giro.animateFloat(
        initialValue = 0f, targetValue = 6.2831855f,
        animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing)),
        label = "fase"
    )

    var entrou by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { entrou = true }
    val escala by animateFloatAsState(
        targetValue = if (entrou) 1f else 0.55f,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "escala"
    )
    val opaco by animateFloatAsState(
        targetValue = if (entrou) 1f else 0f,
        animationSpec = tween(700),
        label = "opaco"
    )
    val estrelas = remember {
        val r = Random(7)
        List(42) { Triple(r.nextFloat(), r.nextFloat(), r.nextFloat() * 6.28f) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Cores.Fundo)
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        // partículas de luz piscando ao fundo
        Canvas(Modifier.fillMaxSize()) {
            estrelas.forEachIndexed { i, e ->
                val brilho = 0.12f + 0.55f * (0.5f + 0.5f * sin(fase + e.third))
                drawCircle(
                    color = (if (i % 4 == 0) Cores.Secundaria else Cores.Destaque).copy(alpha = brilho),
                    radius = (1 + i % 3).dp.toPx() * 0.8f,
                    center = Offset(e.first * size.width, e.second * size.height)
                )
            }
        }

        Column(
            modifier = Modifier.alpha(opaco),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val raioBrilho = size.minDimension / 2f
                    // brilho suave atrás do logo
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Cores.Destaque.copy(alpha = 0.16f + 0.22f * pulso),
                                Color.Transparent
                            ),
                            center = center,
                            radius = raioBrilho
                        ),
                        radius = raioBrilho,
                        center = center
                    )

                    val tracoFora = 6.dp.toPx()
                    val lado = size.minDimension - tracoFora
                    val canto = Offset(tracoFora / 2, tracoFora / 2)
                    val tamanho = Size(lado, lado)

                    // trilho fraco do círculo
                    drawArc(
                        color = Cores.Destaque.copy(alpha = 0.12f),
                        startAngle = 0f, sweepAngle = 360f, useCenter = false,
                        topLeft = canto, size = tamanho, style = Stroke(tracoFora)
                    )
                    // anel de fora girando + bolinha de luz
                    rotate(a1) {
                        drawArc(
                            color = Cores.Destaque,
                            startAngle = 0f, sweepAngle = 100f, useCenter = false,
                            topLeft = canto, size = tamanho, style = Stroke(tracoFora, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = Cores.Destaque.copy(alpha = 0.6f),
                            startAngle = 180f, sweepAngle = 40f, useCenter = false,
                            topLeft = canto, size = tamanho, style = Stroke(tracoFora, cap = StrokeCap.Round)
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 4.dp.toPx(),
                            center = Offset(size.width / 2f + lado / 2f, size.height / 2f)
                        )
                    }
                    // anel de dentro girando ao contrário
                    val recuo = 30.dp.toPx()
                    val tracoDentro = 4.dp.toPx()
                    val ladoDentro = size.minDimension - recuo * 2
                    rotate(a2) {
                        drawArc(
                            color = Cores.Secundaria,
                            startAngle = 30f, sweepAngle = 80f, useCenter = false,
                            topLeft = Offset(recuo, recuo), size = Size(ladoDentro, ladoDentro),
                            style = Stroke(tracoDentro, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = Cores.Secundaria.copy(alpha = 0.5f),
                            startAngle = 210f, sweepAngle = 50f, useCenter = false,
                            topLeft = Offset(recuo, recuo), size = Size(ladoDentro, ladoDentro),
                            style = Stroke(tracoDentro, cap = StrokeCap.Round)
                        )
                        drawCircle(
                            color = Cores.Secundaria,
                            radius = 3.dp.toPx(),
                            center = Offset(size.width / 2f - ladoDentro / 2f, size.height / 2f)
                        )
                    }
                }
                Image(
                    painter = painterResource(R.drawable.kalberdex_capa),
                    contentDescription = Marca.NOME,
                    modifier = Modifier
                        .size(112.dp)
                        .graphicsLayer {
                            scaleX = escala
                            scaleY = escala
                        }
                        .clip(RoundedCornerShape(26.dp))
                )
            }
            Spacer(Modifier.height(26.dp))
            Text(
                Marca.NOME,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 3.sp,
                color = Cores.Destaque,
                maxLines = 1,
                style = TextStyle(
                    shadow = Shadow(
                        color = Cores.Destaque.copy(alpha = 0.8f),
                        offset = Offset(0f, 0f),
                        blurRadius = 28f
                    )
                )
            )
            Spacer(Modifier.height(6.dp))
            Text(
                Marca.CREDITO,
                fontSize = 12.sp,
                color = Cores.Cinza
            )
            Spacer(Modifier.height(18.dp))
            LinearProgressIndicator(
                modifier = Modifier.width(170.dp).height(3.dp).clip(CircleShape),
                color = Cores.Destaque,
                trackColor = Cores.Destaque.copy(alpha = 0.15f)
            )
            Spacer(Modifier.height(12.dp))
            Text(
                mensagem,
                fontSize = 13.sp,
                color = Cores.Cinza,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 32.dp).alpha(pulso)
            )
        }
    }
}
