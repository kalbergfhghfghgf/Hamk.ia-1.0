package com.meuapp.iaoffline

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Tela de abertura: círculo tecnológico girando com o nome da IA. */
@Composable
fun TelaAbertura(mensagem: String) {
    val giro = rememberInfiniteTransition(label = "giro")
    val a1 by giro.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "anelFora"
    )
    val a2 by giro.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "anelDentro"
    )
    val pulso by giro.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulso"
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Cores.Fundo)
            .pointerInput(Unit) { detectTapGestures { } },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Canvas(Modifier.size(170.dp)) {
                val tracoFora = 6.dp.toPx()
                val lado = size.minDimension - tracoFora
                val canto = Offset(tracoFora / 2, tracoFora / 2)
                val tamanho = Size(lado, lado)

                // trilho fraco do círculo
                drawArc(
                    color = Marca.COR_DESTAQUE.copy(alpha = 0.12f),
                    startAngle = 0f, sweepAngle = 360f, useCenter = false,
                    topLeft = canto, size = tamanho, style = Stroke(tracoFora)
                )
                // anel de fora girando
                rotate(a1) {
                    drawArc(
                        color = Marca.COR_DESTAQUE,
                        startAngle = 0f, sweepAngle = 100f, useCenter = false,
                        topLeft = canto, size = tamanho, style = Stroke(tracoFora, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = Marca.COR_DESTAQUE.copy(alpha = 0.6f),
                        startAngle = 180f, sweepAngle = 40f, useCenter = false,
                        topLeft = canto, size = tamanho, style = Stroke(tracoFora, cap = StrokeCap.Round)
                    )
                }
                // anel de dentro girando ao contrário
                val recuo = 28.dp.toPx()
                val tracoDentro = 4.dp.toPx()
                val ladoDentro = size.minDimension - recuo * 2
                rotate(a2) {
                    drawArc(
                        color = Marca.COR_SECUNDARIA,
                        startAngle = 30f, sweepAngle = 80f, useCenter = false,
                        topLeft = Offset(recuo, recuo), size = Size(ladoDentro, ladoDentro),
                        style = Stroke(tracoDentro, cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = Marca.COR_SECUNDARIA.copy(alpha = 0.5f),
                        startAngle = 210f, sweepAngle = 50f, useCenter = false,
                        topLeft = Offset(recuo, recuo), size = Size(ladoDentro, ladoDentro),
                        style = Stroke(tracoDentro, cap = StrokeCap.Round)
                    )
                }
                // ponto de luz no meio
                drawCircle(
                    color = Marca.COR_DESTAQUE.copy(alpha = 0.25f + 0.5f * pulso),
                    radius = 9.dp.toPx()
                )
            }
            Spacer(Modifier.height(28.dp))
            Text(
                Marca.NOME,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 3.sp,
                color = Cores.Destaque
            )
            Spacer(Modifier.height(6.dp))
            Text(
                Marca.CREDITO,
                fontSize = 12.sp,
                color = Cores.Cinza
            )
            Spacer(Modifier.height(10.dp))
            Text(
                mensagem,
                fontSize = 13.sp,
                color = Cores.Cinza,
                modifier = Modifier.alpha(pulso)
            )
        }
    }
}
