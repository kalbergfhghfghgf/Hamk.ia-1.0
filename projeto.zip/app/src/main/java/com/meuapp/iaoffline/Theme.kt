package com.meuapp.iaoffline

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/** Um tema de cor que o usuário pode escolher em Configurações. */
data class Tema(val nome: String, val principal: Color, val secundaria: Color)

object Cores {
    val Temas = listOf(
        Tema("Verde", Marca.COR_DESTAQUE, Marca.COR_SECUNDARIA),
        Tema("Azul", Color(0xFF3D8BFF), Color(0xFF00E5FF)),
        Tema("Roxo", Color(0xFFB06BFF), Color(0xFFFF5CE1)),
        Tema("Rosa", Color(0xFFFF4FA3), Color(0xFFB06BFF)),
        Tema("Laranja", Color(0xFFFF8A1F), Color(0xFFFFD21F)),
        Tema("Vermelho", Color(0xFFFF3B47), Color(0xFFFF8A1F)),
        Tema("Ciano", Color(0xFF00E5FF), Color(0xFF22FF2A))
    )

    var temaIndice by mutableStateOf(0)
        private set

    fun aplicarTema(i: Int) {
        temaIndice = i.coerceIn(0, Temas.lastIndex)
    }

    val Fundo = Color(0xFF050505)
    val Superficie = Color(0xFF0F1412)
    val Destaque: Color get() = Temas[temaIndice].principal
    val Secundaria: Color get() = Temas[temaIndice].secundaria
    val BalaoUsuario: Color get() = lerp(Fundo, Destaque, 0.28f)
    val BalaoIa = Color(0xFF16201B)
    val Alerta = Color(0xFFB3261E)
    val Cinza = Color(0xFF8FA396)
}

@Composable
fun IaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cores.Destaque,
            onPrimary = Color(0xFF021004),
            secondary = Cores.Secundaria,
            background = Cores.Fundo,
            surface = Cores.Superficie,
            onBackground = Color(0xFFECF5EE),
            onSurface = Color(0xFFECF5EE),
            surfaceVariant = Cores.BalaoIa
        ),
        content = content
    )
}
