package com.meuapp.iaoffline

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Cores {
    val Fundo = Color(0xFF050505)
    val Superficie = Color(0xFF0E1511)
    val BalaoUsuario = Color(0xFF0B5A1A)
    val BalaoIa = Color(0xFF16211A)
    val Destaque = Marca.COR_DESTAQUE
    val Alerta = Color(0xFFB3261E)
    val Cinza = Color(0xFF8FA396)
}

@Composable
fun IaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cores.Destaque,
            onPrimary = Color(0xFF021004),
            secondary = Cores.Destaque,
            background = Cores.Fundo,
            surface = Cores.Superficie,
            onBackground = Color(0xFFECF5EE),
            onSurface = Color(0xFFECF5EE),
            surfaceVariant = Cores.BalaoIa
        ),
        content = content
    )
}
